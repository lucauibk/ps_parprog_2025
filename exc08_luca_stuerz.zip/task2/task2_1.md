Manually:       Yes, if x and y do not overlap
By compiler:    Only if aliasing can be ruled out (e.g., with restrict)

3.
S1 has a true dependence on itself
E.g., S1[1,1,2] δ S1[2,1,1] for a[2][1][1]
Distance Vector: 1,0,1
Direction Vector: < , = , >

nur j schleife ist parallelisierbar
![alt text](image.png) selbes problem wie in VO